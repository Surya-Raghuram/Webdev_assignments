/*Create a web appin which there will be the following requirmenets:
1.h1 tag
2.paragraph tag
3..anchor tag

fill all necesary values using js*/

let var_1 = document.querySelector('h1');
var_1.textContent = "Hello";
let var_2 = document.querySelector('p');
var_2.textContent = "This is a paragraph";
let var_3 = document.querySelector('a');
var_3.textContent = "This is an anchor tag";